//
//  main.m
//  启动动画
//
//  Created by Alesary on 15/12/1.
//  Copyright © 2015年 Mr.Chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
