//
//  ViewController.h
//  启动动画
//
//  Created by Alesary on 15/12/1.
//  Copyright © 2015年 Mr.Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

