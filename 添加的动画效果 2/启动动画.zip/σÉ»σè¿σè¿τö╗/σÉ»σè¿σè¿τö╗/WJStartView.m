//
//  WJStartView.m
//  启动动画
//
//  Created by 谭启宏 on 15/12/7.
//  Copyright © 2015年 Mr.Chen. All rights reserved.
//

#import "WJStartView.h"

@interface WJStartView ()

@property (nonatomic,strong)UIImageView *imageView;

@end

@implementation WJStartView


- (instancetype)initWithImageNamesAtiPhone4s:(NSString *)iPhone4s iPhone5s:(NSString *)iPhone5 iPhone6s:(NSString *)iPhone6 iPhone6pls:(NSString *)iPhonepls {
    self = [super init];
    if (self) {
        self.frame = [UIScreen mainScreen].bounds;
        self.imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        self.imageView.tag=11;
        
        NSInteger height = CGRectGetHeight([UIScreen mainScreen].bounds);
        switch (height) {
            case 480://3.5
                self.imageView.image = [UIImage imageNamed:@"launch3.5.png"];
                break;
            case 568://4.0
                self.imageView.image = [UIImage imageNamed:@"launch4.0.png"];
                break;
            case 667://4.7
                self.imageView.image = [UIImage imageNamed:@"launch4.7.png"];
                break;
            case 736://5.5
                self.imageView.image = [UIImage imageNamed:@"launch5.5.png"];
                break;
            default:
                break;
        }
        
        [self addSubview:self.imageView];
    }
    return self;
}

//在这里处理动画的各种效果
- (void)beginAnimation {
    CABasicAnimation *animation=[CABasicAnimation animationWithKeyPath:@"transform.scale"];
    self.imageView.layer.anchorPoint = CGPointMake(.5,.5);
    animation.fromValue = @1.0f;
    animation.toValue = @1.3f;
    animation.fillMode=kCAFillModeForwards;
    animation.removedOnCompletion = NO;
    [animation setAutoreverses:NO];
    
    //动画时间
    animation.duration=0.9;
    animation.delegate=self;
    
    [self.imageView.layer addAnimation:animation forKey:@"scale"];
}



-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    [self.imageView removeFromSuperview];
    [self removeFromSuperview];
}

@end
