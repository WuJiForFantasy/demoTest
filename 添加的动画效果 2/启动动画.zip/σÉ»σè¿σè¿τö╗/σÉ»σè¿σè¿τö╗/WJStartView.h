//
//  WJStartView.h
//  启动动画
//
//  Created by 谭启宏 on 15/12/7.
//  Copyright © 2015年 Mr.Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

//启动视图，配合设置的启动图（就是在最上面盖一层）
@interface WJStartView : UIView


//为了效果最好所以最好弄屏幕大小相同的图片，或者做图的时候叫ui把图片居中

- (instancetype)initWithImageNamesAtiPhone4s:(NSString *)iPhone4s iPhone5s:(NSString *)iPhone5 iPhone6s:(NSString *)iPhone6 iPhone6pls:(NSString *)iPhonepls;//初始化
- (void)beginAnimation;//开始

@end
